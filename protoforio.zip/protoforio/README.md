# protoforio

# my-plans

1. Making coffee website.

2. making power point.

3. make wireframs with figma program flowchart. 

## check marks for how you did.

- [X] made power point.
- [X] makde wireframe with figma.
- [X] added Javascript and all prgram you want on coffe website.
- m[] in design website add tailwind css (font and everything ect.)

Now its 99% done. 

![Coffee](https://user-images.githubusercontent.com/56320722/146451409-4ce46e8f-e7fc-433b-8a20-083676a40bfc.jpg)

![wireframe](https://user-images.githubusercontent.com/56320722/146470797-5a9483a8-1c9f-43f6-943c-a0e1f3e60e0f.png)
